package com.db.unresolved

import com.db.SparkUtils
import com.db.unresolved.reader.{CSVReader, JsonReader, ReaderDf}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql._

object Application extends SparkUtils {

  def main(args: Array[String]): Unit = {

    /**
     * Go through the code and on each exercise, replace '???' with you own code.
     * There is no need to complete the question in order and there is not a unique answer try to develop as much as you can.
     * You can freely google for any information and pseudo-code is accepted if you don't know how to specifically do something
     *
     * NOTE: For more information about the data model check the README.md file.
     */

    val players1JSONPath: String = getClass.getResource("/players1.json").getPath
    val players2JSONPath: String = getClass.getResource("/players2.json").getPath
    val attackingPath: String = getClass.getResource("/attacking.csv").getPath
    val distributionPath: String = getClass.getResource("/distr.csv").getPath
    val goalkeepingPath: String = getClass.getResource("/goalkeeping.csv").getPath
    val goalsPath: String = getClass.getResource("/goals.csv").getPath
    val keyStatsPath: String = getClass.getResource("/key_stats.csv").getPath

    /**
     * =========================================================================================
     * TODO 1:
     * Go to CSVReader.scala class and complete the code so its capable of reading CSV files as a dataframe.
     * Instantiate both a CSV and a JSON reader it to use it later.
     * =========================================================================================
     */
    val csvReader: ReaderDf = CSVReader(Map())
    val jsonReader: ReaderDf = JsonReader(Map())

    /**
     * =========================================================================================
     * TODO 2:
     * Load files data as dataframes with the correct column types.
     * Be aware that 'players1.json' file is not in CSV format
     * =========================================================================================
     */
    val players1Df: DataFrame = jsonReader.readDf(players1JSONPath)
    val players2Df: DataFrame = jsonReader.readDf(players2JSONPath)
    val attackingDf: DataFrame = csvReader.readDf(attackingPath)
    val distributionDf: DataFrame =csvReader.readDf(distributionPath)
    val goalkeepingDf: DataFrame = csvReader.readDf(goalkeepingPath)
    val goalsDf: DataFrame = csvReader.readDf(goalsPath)
    val keyStatsDf: DataFrame = csvReader.readDf(keyStatsPath)

    /**
     * =========================================================================================
     * TODO 3:
     * Combine players1 and players2 dataframes into a single one and get rid of the duplicates
     * =========================================================================================
     */
    val playersDf: DataFrame = players1Df.union(players2Df)

    println("UNION:")
    playersDf.show(false)

    /**
     * =========================================================================================
     * TODO 4:
     * Combine all the dataframes without losing any player's data.
     * 'goals' and 'assists' fields are shared between more than one file. Keep only the one coming from the 'key_stats.csv'.
     * =========================================================================================
     */
    //val pks = Seq("player_name", "club", ???)

    val df2 =attackingDf.join(distributionDf,col("attackingDf.player_name")===col("distributionDf.player_name"))
    val df3= goalkeepingDf.join(df2,col("goalkeepingDf.player_name")===col("df2.player_name"))
    val df4=goalsDf.join(df3, col("goalsDf.player_name")===col("df3.player_name"))
   val fDf= keyStatsDf.join(df4,col("goalsDf.player_name")===col("keyStatsDf.player_name"))

    val fullDf: DataFrame =  playersDf.join(fDf,col("playersDf.player_name")===col("fdf.player_name"))


    assert(fullDf.count == playersDf.count)
    fullDf.printSchema()

    /**
     * =========================================================================================
     * TODO 5:
     * Some players are missing the data.
     * Fill the string gaps with a 'not_available' keyword. The decimals with 0.0 and numbers with 0
     * Create a new function called 'fillGaps' and use it.
     * =========================================================================================
     */

    val columnsInt  = Seq("pass_attempted", "pass_completed","cross_accuracy","cross_attempted","cross_complted","freekicks_taken")
    val columnStr=Seq("club","player_name"," position")
    val decimalVal =Seq("pass_accuracy")

    def fillGaps(df: DataFrame): DataFrame = {
      df.na.fill(0,columnsInt) //fill(0, (col("df.not_available"))
      df.na.fill("not_available",columnStr)
      df.na.fill("not_available",columnStr)

    }

    val curatedFullDf: DataFrame = fillGaps(fullDf)

    println("curatedFullDf:")
    curatedFullDf.show(false)

    /**
     * =========================================================================================
     * TODO 6:
     * Filter out all the players that have played less than 5 matches or did not cover at least 5.5 of distance.
     * =========================================================================================
     */
    val participatingPlayersDf: DataFrame =  fullDf.groupBy(col("player_name")) .agg(count("match_played"))
      .where(col("count") < 5 || col("distance_covered") < 5.5  )
    println("participatingPlayersDf:")
    participatingPlayersDf.show(false)

    /**
     * =========================================================================================
     * TODO 7:
     * From the participating players dataframe.
     * Get the top 5 goalkeepers with the most saved / conceded ratio by descending order.
     * Select only primary keys and relevant columns
     * =========================================================================================
     */

    val window1 = Window.partitionBy(col("position")).orderBy(col("saved").desc)
    val goaliesSaveConcedeRatioDf: DataFrame = fullDf.withColumn("id", row_number().over(window1))
                                              .where(col("position")==="goalkeepers")
                                               .select("player_name","position")
                                               .limit(5)

    println("goaliesSaveConcedeRatioDf:")
    goaliesSaveConcedeRatioDf.show(5, truncate = false)

    /**
     * =========================================================================================
     * TODO 8:
     * Get the number of players that play on each position
     * =========================================================================================
     */

    val numPlayersByPosDf: DataFrame = fullDf
      .groupBy("Position")
      .agg(count("*").as("PlayerCount"))

    println("Num Players By Pos:")
    numPlayersByPosDf.show(false)

    /**
     * =========================================================================================
     * TODO 9:
     * Get the distance covered per minute on each team
     * =========================================================================================
     */
    val clubDistancesPerMinDf: DataFrame = fullDf
      .groupBy("club")
      .agg(sum("distance_covered")  / sum(col("minutes_played"))).as("total_covered_per_minute")

    println("Club distances per minute:")
    clubDistancesPerMinDf.show(false)

    /**
     * =========================================================================================
     * TODO 10:
     * Get the most scorer by each team per position. Use Window.partitionBy() spark function.
     * Filter out the ones with 0 goals. Order by club and position in ascending order
     * Select only relevant columns
     * =========================================================================================
     */

   val window10 = Window.partitionBy(col("position")).orderBy(col("club") ,col("position").desc )
    val mostScorerByClubAndPosDf: DataFrame = fullDf
      .groupBy("position")
      .agg(sum("goal")).as("total_goal")
      .withColumn("club", row_number().over(window10))
        .where(col("goal") > 0 )




    println("Most Scorer by club and position:")
    mostScorerByClubAndPosDf.show(false)

    /**
     * =========================================================================================
     * TODO 11:
     * Group all the players that belong to a club in a single 'array' column named "players"
     * =========================================================================================
     */

    val playersListDf: DataFrame = fullDf.groupBy("Club")
      .agg(collect_list("player_name").as("players"))

    println("Players by Club:")
    playersListDf.show(false)

    /**
     * =========================================================================================
     * TODO 12:
     * As metadata add the following columns to the 'curatedFullDf':
     * - A new column 'id' with a unique identifier for each record
     * - A new column 'execution_date' with the current date in a ISO Date Format
     * =========================================================================================
     */
    import org.apache.spark.sql.functions.{ current_date}

   val window3 = Window.orderBy(col("player_name"))
    val withMetadataDf: DataFrame      = fullDf.withColumn("id", row_number().over(window3)).withColumn("execution_date",current_date())
    println("curatedFullDf with metadata:")
    withMetadataDf.show(false)

    /**
     * =========================================================================================
     * TODO 13:
     * Write the dataframe partitioning by club in parquet format on './landing_area/'
     * Use the SaveMode Overwrite
     * =========================================================================================
     */
    withMetadataDf.write.mode(SaveMode.Overwrite).parquet("/tmp/payer")
    spark.sqlContext.clearCache()
  }

}
