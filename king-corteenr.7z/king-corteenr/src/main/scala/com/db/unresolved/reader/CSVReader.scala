package com.db.unresolved.reader

import org.apache.spark.sql.{DataFrame, SparkSession}

case class CSVReader(options: Map[String, String]) extends ReaderDf {

  override def readDf(path: String)(implicit spark: SparkSession): DataFrame =  spark.read.csv(path)


}
