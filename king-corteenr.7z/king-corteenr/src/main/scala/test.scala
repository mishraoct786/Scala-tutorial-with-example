class test {

}

/*# Input 1: ( [  { }    ]  ( )  { }[ ]  )
# Output: Valid
*/
object test(){


}